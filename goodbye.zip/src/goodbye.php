<?php

function goodbye($data)
{
    return "Goodbye, {$data['name']}!";
}

